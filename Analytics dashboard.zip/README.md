# Northstar Analytics — Enterprise Analytics Dashboard

React + TypeScript + Vite · Redux Toolkit · TanStack Query · TanStack Table · Apache ECharts · Tailwind CSS v4 · React Router

## Run
Requires Node 20.19+ (or 22.12+).

```bash
npm install
npm run dev        # http://localhost:5173
npm run typecheck
npm run lint
npm test
npm run build
```

## Build status
- [x] Phase 1 — project setup, architecture, design tokens, utilities, tests
