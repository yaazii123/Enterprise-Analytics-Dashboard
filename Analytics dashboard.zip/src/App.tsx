import { ErrorBoundary } from '@/components/common/ErrorBoundary';
import { CheckCircle2 } from 'lucide-react';

const STACK = [
  'React + TypeScript',
  'Vite',
  'Redux Toolkit',
  'TanStack Query',
  'TanStack Table',
  'Apache ECharts',
  'Tailwind CSS',
  'React Router',
];

/** Phase 1 shell — replaced by the router + layout in Phase 2. */
export default function App() {
  return (
    <ErrorBoundary>
      <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-4 p-6">
        <h1 className="text-xl font-semibold tracking-tight">Northstar Analytics</h1>
        <p className="text-fg-muted">Phase 1 foundation is in place.</p>
        <ul className="grid gap-2 rounded-lg border border-line bg-surface p-4 shadow-card sm:grid-cols-2">
          {STACK.map((s) => (
            <li key={s} className="flex items-center gap-2">
              <CheckCircle2 size={16} className="text-positive" />
              {s}
            </li>
          ))}
        </ul>
      </main>
    </ErrorBoundary>
  );
}
